function y = vector_function(x)

y(1)=x(1)^2+x(2)^2+x(3)^2-1;
y(2)=sin(x(1))+x(2)^3+x(3);
y(3)=x(1)^2-2*x(2)+x(3);
