%%% 
% Joao Victor Colombari Carlet
% Exercicios lista 3
% Questao 02
%%%

clear all 

x0=[1,1,1];

sol=fsolve(@vector_function,x0)