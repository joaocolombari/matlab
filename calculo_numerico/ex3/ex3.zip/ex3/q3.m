%%% 
% Joao Victor Colombari Carlet
% Exercicios lista 3
% Questao 03
%%%

clear all 

load('sol.mat');

norm(vector_function(sol))