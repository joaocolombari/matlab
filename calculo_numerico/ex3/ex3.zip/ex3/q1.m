%%% 
% Joao Victor Colombari Carlet
% Exercicios lista 3
% Questao 01
%%%

clear all 

x=[1,1,1];

vector_function(x)