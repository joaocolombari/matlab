% SEL0362 - Intelig�ncia Artificial
% Lista 1
% Alunos:   Leonardo Henrique da Silva Silvestrin -- 9283587
%           Joao Victor Colombari Carlet          -- 5274502  

function y = ReLU(x) 
    y = max(0, x);
end